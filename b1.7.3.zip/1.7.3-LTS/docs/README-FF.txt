LTS is using fixed fernflower; sources here: https://github.com/Dereku/fernflower
License: http://www.apache.org/licenses/LICENSE-2.0
