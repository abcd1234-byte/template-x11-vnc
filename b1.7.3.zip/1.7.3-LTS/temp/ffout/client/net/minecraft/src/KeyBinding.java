package net.minecraft.src;

public class KeyBinding {
    public String field_1371_a;
    public int field_1370_b;

    public KeyBinding(String var1, int var2) {
        this.field_1371_a = var1;
        this.field_1370_b = var2;
    }
}
