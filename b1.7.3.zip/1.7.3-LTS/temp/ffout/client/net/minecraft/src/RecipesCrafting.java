package net.minecraft.src;

public class RecipesCrafting {
    public void func_1051_a(CraftingManager var1) {
        var1.func_1121_a(new ItemStack(Block.field_396_av), "###", "# #", "###", '#', Block.field_334_y);
        var1.func_1121_a(new ItemStack(Block.field_445_aC), "###", "# #", "###", '#', Block.field_335_x);
        var1.func_1121_a(new ItemStack(Block.field_387_az), "##", "##", '#', Block.field_334_y);
        var1.func_1121_a(new ItemStack(Block.field_9264_Q), "##", "##", '#', Block.field_393_F);
    }
}
