package net.minecraft.src;

public class ColorizerWater {
    private static int[] field_28183_a = new int[65536];

    public static void func_28182_a(int[] var0) {
        field_28183_a = var0;
    }
}
