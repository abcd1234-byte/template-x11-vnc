package net.minecraft.src;

public class RecipesFood {
    public void func_976_a(CraftingManager var1) {
        var1.func_1121_a(new ItemStack(Item.field_263_D), "Y", "X", "#", 'X', Block.field_415_ag, 'Y', Block.field_414_ah, '#', Item.field_264_C);
        var1.func_1121_a(new ItemStack(Item.field_263_D), "Y", "X", "#", 'X', Block.field_414_ah, 'Y', Block.field_415_ag, '#', Item.field_264_C);
        var1.func_1121_a(new ItemStack(Item.field_25010_ba, 8), "#X#", 'X', new ItemStack(Item.field_21021_aU, 1, 3), '#', Item.field_243_R);
    }
}
