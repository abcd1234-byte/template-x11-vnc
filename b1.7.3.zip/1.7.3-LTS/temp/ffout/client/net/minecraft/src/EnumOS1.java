package net.minecraft.src;

enum EnumOS1 {
    linux,
    solaris,
    windows,
    macos,
    unknown;
}
