package net.minecraft.src;

public class ItemLog extends ItemBlock {
    public ItemLog(int var1) {
        super(var1);
        this.func_21013_d(0);
        this.func_21015_a(true);
    }

    public int func_27009_a(int var1) {
        return Block.field_385_K.func_232_a(2, var1);
    }

    public int func_21012_a(int var1) {
        return var1;
    }
}
