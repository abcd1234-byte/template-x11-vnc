package net.minecraft.src;

import java.util.ArrayList;
import java.util.List;

public class Session {
    public static List field_1667_a = new ArrayList();
    public String field_1666_b;
    public String field_6543_c;
    public String field_6542_d;

    public Session(String var1, String var2) {
        this.field_1666_b = var1;
        this.field_6543_c = var2;
    }

    static {
        field_1667_a.add(Block.field_338_u);
        field_1667_a.add(Block.field_335_x);
        field_1667_a.add(Block.field_409_am);
        field_1667_a.add(Block.field_336_w);
        field_1667_a.add(Block.field_334_y);
        field_1667_a.add(Block.field_385_K);
        field_1667_a.add(Block.field_384_L);
        field_1667_a.add(Block.field_404_ar);
        field_1667_a.add(Block.field_410_al);
        field_1667_a.add(Block.field_382_N);
        field_1667_a.add(Block.field_406_ap);
        field_1667_a.add(Block.field_333_z);
        field_1667_a.add(Block.field_417_ae);
        field_1667_a.add(Block.field_416_af);
        field_1667_a.add(Block.field_415_ag);
        field_1667_a.add(Block.field_414_ah);
        field_1667_a.add(Block.field_393_F);
        field_1667_a.add(Block.field_392_G);
        field_1667_a.add(Block.field_383_M);
        field_1667_a.add(Block.field_419_ac);
        field_1667_a.add(Block.field_386_J);
        field_1667_a.add(Block.field_388_I);
        field_1667_a.add(Block.field_390_H);
        field_1667_a.add(Block.field_412_aj);
        field_1667_a.add(Block.field_413_ai);
        field_1667_a.add(Block.field_407_ao);
        field_1667_a.add(Block.field_408_an);
        field_1667_a.add(Block.field_405_aq);
    }
}
