package net.minecraft.src;

import java.net.URL;

public class SoundPoolEntry {
    public String field_1781_a;
    public URL field_1780_b;

    public SoundPoolEntry(String var1, URL var2) {
        this.field_1781_a = var1;
        this.field_1780_b = var2;
    }
}
