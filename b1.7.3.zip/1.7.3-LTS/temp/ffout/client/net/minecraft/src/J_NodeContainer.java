package net.minecraft.src;

interface J_NodeContainer {
    void func_27290_a(J_JsonNodeBuilder var1);

    void func_27289_a(J_JsonFieldBuilder var1);
}
