package net.minecraft.src;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class Packet0KeepAlive extends Packet {
    public void func_323_a(NetHandler var1) {
    }

    public void func_327_a(DataInputStream var1) throws IOException {
    }

    public void func_322_a(DataOutputStream var1) throws IOException {
    }

    public int func_329_a() {
        return 0;
    }
}
