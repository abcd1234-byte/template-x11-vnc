package net.minecraft.src;

public class SpawnListEntry {
    public Class field_25212_a;
    public int field_25211_b;

    public SpawnListEntry(Class var1, int var2) {
        this.field_25212_a = var1;
        this.field_25211_b = var2;
    }
}
