package net.minecraft.src;

public class MaterialTransparent extends Material {
    public MaterialTransparent(MapColor var1) {
        super(var1);
        this.func_27284_f();
    }

    public boolean func_878_a() {
        return false;
    }

    public boolean func_881_b() {
        return false;
    }

    public boolean func_880_c() {
        return false;
    }
}
