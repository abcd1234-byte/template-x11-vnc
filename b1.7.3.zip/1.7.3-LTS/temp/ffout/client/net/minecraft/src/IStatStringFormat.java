package net.minecraft.src;

public interface IStatStringFormat {
    String func_27343_a(String var1);
}
