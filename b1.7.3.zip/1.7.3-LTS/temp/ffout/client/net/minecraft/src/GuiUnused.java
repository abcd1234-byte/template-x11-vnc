package net.minecraft.src;

public class GuiUnused extends GuiScreen {
    private String field_997_a;
    private String field_998_h;

    public void func_6448_a() {
    }

    public void func_571_a(int var1, int var2, float var3) {
        this.func_549_a(0, 0, this.field_951_c, this.field_950_d, -12574688, -11530224);
        this.func_548_a(this.field_6451_g, this.field_997_a, this.field_951_c / 2, 90, 16777215);
        this.func_548_a(this.field_6451_g, this.field_998_h, this.field_951_c / 2, 110, 16777215);
        super.func_571_a(var1, var2, var3);
    }

    protected void func_580_a(char var1, int var2) {
    }
}
