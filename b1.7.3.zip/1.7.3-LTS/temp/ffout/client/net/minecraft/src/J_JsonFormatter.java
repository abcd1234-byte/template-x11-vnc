package net.minecraft.src;

public interface J_JsonFormatter {
    String func_27327_a(J_JsonRootNode var1);
}
