package net.minecraft.src;

public class MaterialLogic extends Material {
    public MaterialLogic(MapColor var1) {
        super(var1);
    }

    public boolean func_878_a() {
        return false;
    }

    public boolean func_881_b() {
        return false;
    }

    public boolean func_880_c() {
        return false;
    }
}
