package net.minecraft.src;

public interface IInvBasic {
    void func_20134_a(InventoryBasic var1);
}
