package net.minecraft.src;

public class UnexpectedThrowable {
    public final String field_6515_a;
    public final Throwable field_6514_b;

    public UnexpectedThrowable(String var1, Throwable var2) {
        this.field_6515_a = var1;
        this.field_6514_b = var2;
    }
}
