package net.minecraft.src;

public class BiomeGenDesert extends BiomeGenBase {
}
