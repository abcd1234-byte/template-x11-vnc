package net.minecraft.src;

public interface IRecipe {
    boolean func_21135_a(InventoryCrafting var1);

    ItemStack func_21136_b(InventoryCrafting var1);

    int func_1184_a();

    ItemStack func_25117_b();
}
