package net.minecraft.src;

public class J_JsonNodeDoesNotMatchJsonNodeSelectorException extends IllegalArgumentException {
    J_JsonNodeDoesNotMatchJsonNodeSelectorException(String var1) {
        super(var1);
    }
}
