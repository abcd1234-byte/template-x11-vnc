package net.minecraft.src;

public class StatCollector {
    private static StringTranslate field_25201_a = StringTranslate.func_20162_a();

    public static String func_25200_a(String var0) {
        return field_25201_a.func_20163_a(var0);
    }

    public static String func_25199_a(String var0, Object... var1) {
        return field_25201_a.func_20160_a(var0, var1);
    }
}
