package net.minecraft.src;

final class StatTypeSimple implements IStatType {
    public String func_27192_a(int var1) {
        return StatBase.func_27083_i().format((long)var1);
    }
}
