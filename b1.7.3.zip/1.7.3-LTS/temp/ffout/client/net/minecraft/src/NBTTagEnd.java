package net.minecraft.src;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

public class NBTTagEnd extends NBTBase {
    void func_736_a(DataInput var1) throws IOException {
    }

    void func_735_a(DataOutput var1) throws IOException {
    }

    public byte func_733_a() {
        return 0;
    }

    public String toString() {
        return "END";
    }
}
