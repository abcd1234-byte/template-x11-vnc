package net.minecraft.src;

public class RecipesDyes {
    public void func_21157_a(CraftingManager var1) {
        for(int var2 = 0; var2 < 16; ++var2) {
            var1.func_21187_b(new ItemStack(Block.field_419_ac, 1, BlockCloth.func_21035_d(var2)), new ItemStack(Item.field_21021_aU, 1, var2), new ItemStack(Item.field_233_c[Block.field_419_ac.field_376_bc], 1, 0));
        }

        var1.func_21187_b(new ItemStack(Item.field_21021_aU, 2, 11), Block.field_417_ae);
        var1.func_21187_b(new ItemStack(Item.field_21021_aU, 2, 1), Block.field_416_af);
        var1.func_21187_b(new ItemStack(Item.field_21021_aU, 3, 15), Item.field_21020_aV);
        var1.func_21187_b(new ItemStack(Item.field_21021_aU, 2, 9), new ItemStack(Item.field_21021_aU, 1, 1), new ItemStack(Item.field_21021_aU, 1, 15));
        var1.func_21187_b(new ItemStack(Item.field_21021_aU, 2, 14), new ItemStack(Item.field_21021_aU, 1, 1), new ItemStack(Item.field_21021_aU, 1, 11));
        var1.func_21187_b(new ItemStack(Item.field_21021_aU, 2, 10), new ItemStack(Item.field_21021_aU, 1, 2), new ItemStack(Item.field_21021_aU, 1, 15));
        var1.func_21187_b(new ItemStack(Item.field_21021_aU, 2, 8), new ItemStack(Item.field_21021_aU, 1, 0), new ItemStack(Item.field_21021_aU, 1, 15));
        var1.func_21187_b(new ItemStack(Item.field_21021_aU, 2, 7), new ItemStack(Item.field_21021_aU, 1, 8), new ItemStack(Item.field_21021_aU, 1, 15));
        var1.func_21187_b(new ItemStack(Item.field_21021_aU, 3, 7), new ItemStack(Item.field_21021_aU, 1, 0), new ItemStack(Item.field_21021_aU, 1, 15), new ItemStack(Item.field_21021_aU, 1, 15));
        var1.func_21187_b(new ItemStack(Item.field_21021_aU, 2, 12), new ItemStack(Item.field_21021_aU, 1, 4), new ItemStack(Item.field_21021_aU, 1, 15));
        var1.func_21187_b(new ItemStack(Item.field_21021_aU, 2, 6), new ItemStack(Item.field_21021_aU, 1, 4), new ItemStack(Item.field_21021_aU, 1, 2));
        var1.func_21187_b(new ItemStack(Item.field_21021_aU, 2, 5), new ItemStack(Item.field_21021_aU, 1, 4), new ItemStack(Item.field_21021_aU, 1, 1));
        var1.func_21187_b(new ItemStack(Item.field_21021_aU, 2, 13), new ItemStack(Item.field_21021_aU, 1, 5), new ItemStack(Item.field_21021_aU, 1, 9));
        var1.func_21187_b(new ItemStack(Item.field_21021_aU, 3, 13), new ItemStack(Item.field_21021_aU, 1, 4), new ItemStack(Item.field_21021_aU, 1, 1), new ItemStack(Item.field_21021_aU, 1, 9));
        var1.func_21187_b(new ItemStack(Item.field_21021_aU, 4, 13), new ItemStack(Item.field_21021_aU, 1, 4), new ItemStack(Item.field_21021_aU, 1, 1), new ItemStack(Item.field_21021_aU, 1, 1), new ItemStack(Item.field_21021_aU, 1, 15));
    }
}
