package net.minecraft.src;

public interface IInventory {
    int func_469_c();

    ItemStack func_468_c(int var1);

    ItemStack func_473_a(int var1, int var2);

    void func_472_a(int var1, ItemStack var2);

    String func_471_d();

    int func_470_e();

    void func_474_j_();

    boolean func_20070_a_(EntityPlayer var1);
}
