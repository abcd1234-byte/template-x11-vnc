# Decompiling
When decompiling, make sure you have Java 8 or Java 7 (Preferably 8) in your PATH (or equivalent).
If not, MCP will start trying to use whatever Java it manages to find, which is REALLY bad.

# Recompiling
See above.

# Reobfuscation
If you recompiled with Java 9 or above, when reobfuscating, SpecialSource with error out with "unsupported major class version".
This means MCP went ahead and used whatever Java install it could.
